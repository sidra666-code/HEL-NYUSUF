# Helin & Yusuf Vercel Telegram Bildirimi

## Kurulum
1. Bu projeyi GitHub'a yükle
2. Vercel ile import et
3. Environment Variables ekle:
   - BOT_TOKEN = Telegram bot token
   - CHAT_ID = kendi chat ID
4. Deploy et ve siteye girişlerde bildirim gelmeye başlar 🚀
