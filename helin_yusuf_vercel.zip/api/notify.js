export default async function handler(req, res) {
  const token = process.env.BOT_TOKEN;
  const chat_id = process.env.CHAT_ID;
  const message = "🚨 Siteye biri girdi!";

  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id, text: message })
  });

  res.status(200).json({ ok: true });
}
